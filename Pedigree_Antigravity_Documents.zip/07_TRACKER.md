# PEDIGREE — Implementation Tracker

Status: `[ ]` Not started, `[-]` In progress, `[x]` Done, `[!]` Blocked.

## Setup
- [ ] Repository
- [ ] React/Vite
- [ ] Express
- [ ] Tailwind
- [ ] MongoDB
- [ ] Environment config
- [ ] Routing
- [ ] Error handling

## Authentication
- [ ] User registration
- [ ] User login
- [ ] Counselor login
- [ ] Admin login
- [ ] bcrypt
- [ ] JWT
- [ ] Protected routes
- [ ] RBAC
- [ ] Logout

## User
- [ ] Dashboard
- [ ] Profile
- [ ] Family list
- [ ] Create/edit/archive family

## Family
- [ ] Add/edit/delete member
- [ ] Add/delete relationship
- [ ] Relationship validation
- [ ] Add/edit/remove condition
- [ ] Data completeness

## Pedigree
- [ ] Graph transformer
- [ ] Visualization
- [ ] Legend
- [ ] Zoom
- [ ] Pan
- [ ] Member selection
- [ ] Details panel

## AIES
- [ ] Fact model
- [ ] Fact builder
- [ ] Rule model
- [ ] Rule evaluator
- [ ] Result aggregator
- [ ] Explanation
- [ ] Guidance
- [ ] Assessment snapshot
- [ ] History

## Counselor
- [ ] Dashboard
- [ ] Assigned cases
- [ ] Case details
- [ ] Pedigree review
- [ ] Assessment review
- [ ] Notes
- [ ] Recommendations
- [ ] Status
- [ ] Report review

## Admin
- [ ] Dashboard
- [ ] Users
- [ ] Counselors
- [ ] Conditions
- [ ] Rules
- [ ] Assignments
- [ ] Analytics
- [ ] Audit logs
- [ ] Settings

## Reports
- [ ] Template
- [ ] Assessment injection
- [ ] Pedigree summary
- [ ] Triggered rules
- [ ] Guidance
- [ ] Counselor notes
- [ ] Disclaimer
- [ ] PDF download

## QA
- [ ] Frontend validation
- [ ] Backend validation
- [ ] RBAC tests
- [ ] Rule tests
- [ ] API tests
- [ ] Responsive test
- [ ] Accessibility
- [ ] Security review
- [ ] Console cleanup
- [ ] Demo seed data
- [ ] README

## Priority
### P0
Authentication, RBAC, family, relationships, pedigree, rule engine, assessment, core counselor/admin.

### P1
Reports, audit logs, notifications, analytics.

### P2
Advanced filters and extra visualizations.
